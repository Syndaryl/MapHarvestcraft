﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Extensions
{
    public static class StringExtensionMethods
    {
        public static string SafeValue(this string t, string defaultValue)
        {
            return string.IsNullOrEmpty(t)? defaultValue: t;
        }
    }
}
